//
//  main.cpp
//  AVLTree
//
//  Created by Samuel von Bausznern on 29.04.13.
//  Copyright (c) 2013 Samuel von Bausznern. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[])
{

    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}

