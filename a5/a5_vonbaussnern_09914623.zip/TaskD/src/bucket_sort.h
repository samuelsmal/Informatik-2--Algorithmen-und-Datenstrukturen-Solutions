//
//  Created by Rafael Ballester on 10.04.13.
//  Copyright (c) 2013 Universität Zürich. All rights reserved.
//

#ifndef _BUCKET_SORT_H_
#define _BUCKET_SORT_H_

#include <vector>

void bucket_sort (std::vector < int >&numbers_);

#endif
