//
//  Created by Rafael Ballester on 10.04.13.
//  Copyright (c) 2013 Universität Zürich. All rights reserved.
//

#ifndef _SELECTION_SORT_H_
#define _SELECTION_SORT_H_

#include <vector>

void selection_sort (std::vector < int >&numbers_);

#endif
