//
//  exceptions.h
//  stack_arraybased
//
//  Created by Loc Nguyen on 16.02.12.
//  Copyright (c) 2012 Universität Zürich. All rights reserved.
//

#ifndef stack_arraybased_exceptions_h
#define stack_arraybased_exceptions_h

class OverFlow
{
    public:
    void overflowoutput();
};

class UnderFlow
{
    public:
    void underflowoutput();
};

#endif
